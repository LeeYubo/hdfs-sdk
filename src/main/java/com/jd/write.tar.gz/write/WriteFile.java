package com.jd.write;

import java.util.Arrays;

/**
 * @author liyubo
 * @create 2020-08-07 9:31 上午
 **/
public class WriteFile {

//    private static final Logger logger = LoggerFactory.getLogger(WriteFile.class);
    private static final long PARENT_ID = 5;
    private static final int STATUS_SUCCESS = 0;

    public native int NewClient();

    public native long create(long pid, int index);

    public native int open(long iid);

    public native int write(long iid, long offset, String data);

    public native int close(long iid);

    static {
        // load c dynamic library
        System.out.println("Start to load library write.");
        System.setProperty("java.library.path", "/Users/liyubo/gitpath/work/hdfs-sdk/src/main/java/com/jd/write");
        System.out.println("set library path finished.");
        System.out.println(System.getProperty("java.library.path"));
        System.loadLibrary("write");
    }

    public int createFile(int fileIndex, long fileSize) {
        int status;
        long inodeId;

        // init
        WriteFile writeFile = new WriteFile();
        status = writeFile.NewClient();
        if (status != STATUS_SUCCESS) {
            System.out.println("Init cfs client failed.");
            return status;
        }
        System.out.println("Init cfs client success.");

        // create a file, and get a inode
        inodeId = writeFile.create(PARENT_ID, fileIndex);
        if (inodeId < 0) {
            System.out.println("Create file failed, inode id : "+ inodeId);
            return Long.valueOf(inodeId).intValue();
        }
        System.out.println("Create file success, inode id : "+ inodeId);

        // open stream via a inode
        status = writeFile.open(inodeId);
        if (status != STATUS_SUCCESS) {
            System.out.println("open file stream failed.");
            return status;
        }
        System.out.println("Open file stream success.");

        // write data to stream
        long offset = 0;
        int writeLength;
        String data = createData(1024);

        while (fileSize > 0) {
            writeLength = writeFile.write(inodeId, offset, data);
            System.out.println("Write length : " + writeLength);
            offset += writeLength;
            fileSize -= writeLength;
        }
        System.out.println("Write file finished.");

        // close
        status = writeFile.close(inodeId);
        if (status != STATUS_SUCCESS) {
            System.out.println("close file failed");
            return status;
        }
        return 0;
    }

    private static String createData(int dataSize) {
        byte[] bytes = new byte[dataSize];
        Arrays.fill(bytes, (byte) 97);
        return new String(bytes);
    }

    public static void main(String[] args) {
        WriteFile writeFile = new WriteFile();

        // write 1MB file
        int status;
        int fileIndex = 100;
        long fileSize = 10 * 1024 * 1024;
        status = writeFile.createFile(fileIndex, fileSize);
        if (status != STATUS_SUCCESS) {
            System.out.println("Write file of 1MB failed.");
            return;
        }
        System.out.println("Write file of 1MB success.");
    }
}
